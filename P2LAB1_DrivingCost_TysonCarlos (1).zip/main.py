cars_mpg = float(input())
gas = float(input())
x = (gas * 20) / cars_mpg 
y = (gas * 75) / cars_mpg 
z = (gas * 500) / cars_mpg
print('{:.2f} {:.2f} {:.2f}'.format(x, y, z))